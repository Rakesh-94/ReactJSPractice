import React,{useState} from 'react'
// import {useNavigate} from "react-router-dom"
import "./Login.css"

import {useNavigate } from 'react-router-dom';



const Login = () => {
    const history = useNavigate();

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loginError, setLoginError] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);


    const correctName = 'Rakesh pal';
    const correctEmail = 'rakesh@gmail.com';
    const correctPassword = 'password123';


    const handleSubmit = (e) => {
        e.preventDefault();
    
        if (name === correctName && email === correctEmail && password === correctPassword) {
          setIsLoggedIn(true)
          setLoginError(false);
        } else {
          setIsLoggedIn(false);
          setLoginError(true);
        }
      };


  return (
    <div >
        <main className='Main'>
            <form onSubmit={handleSubmit}>
                <h1>Login now</h1>
                <input type="text" name="name" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)}/>
                <input type="email" name="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}/>
                <input type="password" name="password" placeholder="password" value={password} onChange={(e) => setPassword(e.target.value)}/>
                <button type="submit">Login</button>
                
            </form>
            {isLoggedIn  && history("/Home")}
            {loginError && <p>Error: Incorrect credentials.</p>}
        </main>
        

    </div>
  )
}

export default Login;