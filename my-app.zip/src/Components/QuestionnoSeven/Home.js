import React from "react";

const Home = (props) => {
  return (
    
    <div>
      <main className="Main">
        <form >
          <h1>Your are Login now</h1>
          <h1>Welcome, Back</h1>
        </form>
      </main>
    </div>
  );
};

export default Home;
