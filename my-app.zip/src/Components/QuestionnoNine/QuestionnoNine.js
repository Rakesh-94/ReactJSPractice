import React from 'react'
import Allroute from './Allroute'

const QuestionnoNine = () => {
  return (
    <div>
        <Allroute />
    </div>
  )
}

export default QuestionnoNine