import React from 'react'
import Nav from './Nav'

const Blog = () => {
  return (
    <div>
      <Nav />
        <h1>This is Blog page</h1>
    </div>
  )
}

export default Blog