import React from 'react'
import Nav from './Nav'

const Home = () => {
  return (
    <div>
      <Nav />
        <h1>This is Home page</h1>
    </div>
  )
}

export default Home