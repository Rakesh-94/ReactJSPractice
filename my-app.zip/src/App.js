import './App.css';

import RouteAll from './Components/RouteAll';

// import QuestionnoSix from './Components/QuestionnoSix/QuestionnoSix';
// import QuestionnoSeven from './Components/QuestionnoSeven/QuestionnoSeven';
// import QuestionnoNine from './Components/QuestionnoNine/QuestionnoNine';



function App() {
  return (
    <div className="App">
      
      <RouteAll />  
      {/* <QuestionnoSix /> */}
      {/* <QuestionnoSeven /> */}
      {/* <QuestionnoNine /> */}



    </div>
  );
}

export default App;
